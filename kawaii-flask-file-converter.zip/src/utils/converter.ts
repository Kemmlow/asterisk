import * as XLSX from 'xlsx';
import { readDbf, writeDbf, DbfField } from './dbf';

export interface ParsedFile {
  name: string;
  extension: SupportedFormat;
  rows: any[];
  headers: string[];
  rawFields?: DbfField[]; // specifically for DBF preservation
  size: number;
}

export type SupportedFormat = 'csv' | 'xlsx' | 'xls' | 'dbf';

export const FORMAT_INFO = {
  csv: { name: 'CSV (Comma Separated Values)', label: 'CSV (.csv)', desc: 'Standard text format. Simple, readable in Notepad.' },
  xlsx: { name: 'Excel Workbook', label: 'Excel (.xlsx)', desc: 'Modern Excel format. Supports styling, multiple sheets.' },
  xls: { name: 'Excel 97-2003 Workbook', label: 'Excel (.xls)', desc: 'Older Excel format. Widely compatible.' },
  dbf: { name: 'dBase Database', label: 'dBase (.dbf)', desc: 'Database file. Used in legacy software, foxpro.' }
};

/**
 * Sanitizes the file name to prevent malicious downloads/paths.
 */
function sanitizeFileName(name: string): string {
  return name.replace(/[^a-zA-Z0-9_\-\s]/g, '').trim();
}

/**
 * Parses an uploaded file (CSV, XLSX, XLS, DBF) and converts it to a standard internal structure.
 */
export function parseFile(file: File): Promise<ParsedFile> {
  return new Promise((resolve, reject) => {
    // Basic file upload sanitization
    if (!file) {
      return reject(new Error('No file provided! Please choose a file.'));
    }

    const ext = file.name.split('.').pop()?.toLowerCase() as SupportedFormat;
    if (!['csv', 'xlsx', 'xls', 'dbf'].includes(ext)) {
      return reject(
        new Error(`The file format ".${ext}" is not supported! Please upload a .csv, .xlsx, .xls, or .dbf file.`)
      );
    }

    // Safety limit: 50MB for browser processing to avoid crashing the tab
    const MAX_SIZE_MB = 50;
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      return reject(
        new Error(`The file is too large (${(file.size / (1024 * 1024)).toFixed(1)} MB)! Please upload a file smaller than ${MAX_SIZE_MB} MB.`)
      );
    }

    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const buffer = e.target?.result as ArrayBuffer;
        const cleanName = sanitizeFileName(file.name.replace(/\.[^/.]+$/, ""));
        
        // 1. Handle DBF Format
        if (ext === 'dbf') {
          const dbfData = readDbf(buffer);
          
          if (dbfData.records.length === 0 && dbfData.fields.length === 0) {
            throw new Error('This dBase file appears to be empty or corrupted.');
          }

          resolve({
            name: cleanName || 'untitled',
            extension: ext,
            rows: dbfData.records,
            headers: dbfData.fields.map(f => f.name),
            rawFields: dbfData.fields,
            size: file.size
          });
          return;
        }

        // 2. Handle Spreadsheet Formats using SheetJS
        // Excel and CSV files can be read using SheetJS from array buffers
        const arrayBytes = new Uint8Array(buffer);
        const wb = XLSX.read(arrayBytes, { 
          type: 'array',
          cellDates: true, // Auto-convert date strings to JS Date objects
          raw: false // Formatted strings where applicable
        });

        const sheetName = wb.SheetNames[0];
        if (!sheetName) {
          throw new Error('This file has no sheets! It appears to be an empty or broken spreadsheet.');
        }

        const ws = wb.Sheets[sheetName];
        
        // Extract rows as array of objects
        // defval: '' ensures that empty/missing cells are set to empty string instead of undefined
        const rows = XLSX.utils.sheet_to_json<any>(ws, { defval: '' });

        if (rows.length === 0) {
          throw new Error('This spreadsheet has a header but contains no data records.');
        }

        // Attempt to extract headers in order by reading row 1 cell values
        const headers: string[] = [];
        if (ws['!ref']) {
          const range = XLSX.utils.decode_range(ws['!ref']);
          const startRow = range.s.r;
          
          for (let C = range.s.c; C <= range.e.c; ++C) {
            const address = XLSX.utils.encode_cell({ r: startRow, c: C });
            const cell = ws[address];
            if (cell && cell.v !== undefined) {
              const hText = String(cell.v).trim();
              if (hText) headers.push(hText);
            }
          }
        }

        // Fallback for headers if SheetJS ref wasn't parseable
        const fallbackHeaders = Object.keys(rows[0]);
        const finalHeaders = headers.length > 0 ? headers : fallbackHeaders;

        resolve({
          name: cleanName || 'untitled',
          extension: ext,
          rows: rows,
          headers: finalHeaders,
          size: file.size
        });

      } catch (err: any) {
        // Detailed logging for auditing and debugging
        console.error(`[Conversion Error]: File reading failed for ${file.name}.`, err);
        reject(
          new Error(`Oh no! Something went wrong reading your file. ${err.message || 'The file might be corrupted.'}`)
        );
      }
    };

    reader.onerror = () => {
      reject(new Error('Oops! A system error occurred while uploading your file. Please try again or check your file permissions.'));
    };

    // Begin reading file
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Converts internal JSON array records to the selected output format and returns a Blob for download.
 */
export function convertAndDownload(
  rows: any[],
  outputFormat: SupportedFormat,
  baseName: string,
  customHeaders?: string[]
): { blob: Blob; fileName: string } {
  let blob: Blob;
  const sanitizedBase = sanitizeFileName(baseName) || 'converted_file';
  const fileName = `${sanitizedBase}.${outputFormat}`;

  try {
    if (rows == null || rows.length === 0) {
      throw new Error('There is no data to convert. The file appears to be empty!');
    }

    // 1. Convert to dBase (.dbf)
    if (outputFormat === 'dbf') {
      const arrayBuffer = writeDbf(rows);
      blob = new Blob([arrayBuffer], { type: 'application/x-dbf' });
    } 
    
    // 2. Convert to CSV (.csv)
    else if (outputFormat === 'csv') {
      const ws = XLSX.utils.json_to_sheet(rows, { header: customHeaders });
      const csvString = XLSX.utils.sheet_to_csv(ws);
      
      // Prepend BOM (Byte Order Mark) for Excel to open CSVs with UTF-8 correctly
      const BOM = '\uFEFF';
      blob = new Blob([BOM + csvString], { type: 'text/csv;charset=utf-8;' });
    } 
    
    // 3. Convert to Excel (.xlsx)
    else if (outputFormat === 'xlsx') {
      const ws = XLSX.utils.json_to_sheet(rows, { header: customHeaders });
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      
      const arrayBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
      blob = new Blob([arrayBuffer], { 
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
      });
    } 
    
    // 4. Convert to Legacy Excel (.xls)
    else if (outputFormat === 'xls') {
      const ws = XLSX.utils.json_to_sheet(rows, { header: customHeaders });
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      
      const arrayBuffer = XLSX.write(wb, { bookType: 'xls', type: 'array' });
      blob = new Blob([arrayBuffer], { 
        type: 'application/vnd.ms-excel' 
      });
    } 
    
    else {
      throw new Error(`The format "${outputFormat}" is not supported for downloading!`);
    }

    return { blob, fileName };

  } catch (err: any) {
    console.error(`[Conversion Error]: Creation of ${outputFormat} failed.`, err);
    throw new Error(`Oh no! We couldn't create the .${outputFormat} file. ${err.message || ''}`);
  }
}

/**
 * Utility to download a Blob in the browser
 */
export function triggerDownload(blob: Blob, fileName: string): void {
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.style.display = 'none';
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}
