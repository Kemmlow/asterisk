/**
 * DBF (dBase III) Reader and Writer in Pure TypeScript
 * This module enables reading and writing .dbf files in the browser without server dependencies.
 * Perfect for client-side processing, ensuring data privacy and instant conversions.
 */

export interface DbfField {
  name: string;
  type: 'C' | 'N' | 'L' | 'D'; // Character, Numeric, Logical, Date
  length: number;
  decimalCount: number;
}

export interface DbfData {
  fields: DbfField[];
  records: Array<Record<string, any>>;
}

/**
 * Reads a DBF file from an ArrayBuffer and parses it into JSON records and fields.
 */
export function readDbf(buffer: ArrayBuffer): DbfData {
  if (!buffer || buffer.byteLength < 32) {
    throw new Error('Invalid DBF file: File is too small to contain a header.');
  }

  const view = new DataView(buffer);
  
  // Byte 0: File type (0x03 = dBASE III without memo)
  const signature = view.getUint8(0);
  // Accept standard dBase signatures
  if (signature !== 0x03 && signature !== 0x83 && signature !== 0xF5 && signature !== 0x8B) {
    console.warn(`Unexpected DBF signature: 0x${signature.toString(16)}. Proceeding anyway...`);
  }

  // Bytes 4-7: Number of records in data file (Little Endian)
  const recordCount = view.getUint32(4, true);
  
  // Bytes 8-9: Length of header structure (Little Endian)
  const headerLength = view.getUint16(8, true);
  
  // Bytes 10-11: Length of each record (Little Endian)
  const recordLength = view.getUint16(10, true);

  if (buffer.byteLength < headerLength) {
    throw new Error('Invalid DBF file: Header length exceeds file size.');
  }

  const fields: DbfField[] = [];
  let offset = 32;

  // Use TextDecoder to handle accented characters safely in Western European text
  const decoder = new TextDecoder('windows-1252');

  // Field descriptors are 32 bytes each. 
  // We read until we reach the terminator (0x0D) or we exceed the header length.
  while (offset < headerLength - 1 && view.getUint8(offset) !== 0x0D) {
    if (offset + 32 > headerLength) break;

    // Field name (0-10): up to 11 bytes, 0-terminated
    const nameBytes = new Uint8Array(buffer, offset, 11);
    let nameLen = 0;
    while (nameLen < 11 && nameBytes[nameLen] !== 0) {
      nameLen++;
    }
    const name = decoder.decode(new Uint8Array(buffer, offset, nameLen)).trim();

    // Field type (11)
    const typeChar = String.fromCharCode(view.getUint8(offset + 11));
    let type: 'C' | 'N' | 'L' | 'D' = 'C';
    if (['C', 'N', 'L', 'D'].includes(typeChar)) {
      type = typeChar as 'C' | 'N' | 'L' | 'D';
    } else {
      // Fallback for uncommon types (Memo, float, etc.) to character
      type = 'C';
    }

    // Field length (16)
    const length = view.getUint8(offset + 16);

    // Field decimal count (17)
    const decimalCount = view.getUint8(offset + 17);

    fields.push({ name, type, length, decimalCount });
    offset += 32;
  }

  const records: Array<Record<string, any>> = [];
  let recordOffset = headerLength;

  // Process all records
  for (let r = 0; r < recordCount; r++) {
    // If we exceed the buffer size, stop parsing (truncated file)
    if (recordOffset + recordLength > buffer.byteLength) {
      console.warn(`File truncated: expected ${recordCount} records, but reached end of file at ${r} records.`);
      break;
    }

    // First byte of record is the delete flag (0x20 = active, 0x2A = asterisk/deleted)
    const deleteFlag = view.getUint8(recordOffset);
    
    // Process only active (non-deleted) records
    if (deleteFlag === 0x20) {
      const record: Record<string, any> = {};
      let fieldOffset = recordOffset + 1; // skip delete flag

      for (const field of fields) {
        if (fieldOffset + field.length > buffer.byteLength) break;

        // Read the string value
        const fieldBytes = new Uint8Array(buffer, fieldOffset, field.length);
        const rawStr = decoder.decode(fieldBytes).trim();

        if (field.type === 'N') {
          // Numeric
          record[field.name] = rawStr === '' ? null : Number(rawStr);
        } else if (field.type === 'L') {
          // Logical ('T', 't', 'Y', 'y' for true; 'F', 'f', 'N', 'n' for false; '?' for uninitialized)
          const char = rawStr.toUpperCase();
          record[field.name] = char === 'T' || char === 'Y';
        } else if (field.type === 'D') {
          // Date (YYYYMMDD)
          if (rawStr.length === 8) {
            const yyyy = rawStr.substring(0, 4);
            const mm = rawStr.substring(4, 6);
            const dd = rawStr.substring(6, 8);
            record[field.name] = `${yyyy}-${mm}-${dd}`;
          } else {
            record[field.name] = rawStr;
          }
        } else {
          // Character
          record[field.name] = rawStr;
        }

        fieldOffset += field.length;
      }
      records.push(record);
    }
    
    recordOffset += recordLength;
  }

  return { fields, records };
}

/**
 * Writes a DBF file from JSON records and optionally field descriptors.
 */
export function writeDbf(records: Array<Record<string, any>>, customFields?: DbfField[]): ArrayBuffer {
  let fields = customFields;

  // 1. Infer fields from data if not provided
  if (!fields || fields.length === 0) {
    fields = [];
    if (records.length > 0) {
      const first = records[0];
      const seenNames = new Set<string>();

      for (const key of Object.keys(first)) {
        // DBF field names are max 10 chars, uppercase, alphanumeric or underscore
        let fieldName = key.toUpperCase().replace(/[^A-Z0-9_]/g, '_').substring(0, 10);
        if (!fieldName || /^\d/.test(fieldName)) {
          fieldName = 'F_' + fieldName.substring(0, 8);
        }
        
        // Ensure name uniqueness
        let base = fieldName;
        let suffix = 1;
        while (seenNames.has(fieldName)) {
          const suffixStr = String(suffix);
          fieldName = base.substring(0, 10 - suffixStr.length) + suffixStr;
          suffix++;
        }
        seenNames.add(fieldName);

        const val = first[key];
        let type: 'C' | 'N' | 'L' = 'C';
        let length = 254;
        let decimalCount = 0;

        if (typeof val === 'number') {
          type = 'N';
          length = 18;
          decimalCount = 4; // default to 4 decimals for float-like values
        } else if (typeof val === 'boolean') {
          type = 'L';
          length = 1;
          decimalCount = 0;
        } else {
          // Strings or other
          type = 'C';
          length = 254; // standard max length for dBase III fields
          decimalCount = 0;
        }

        fields.push({ name: fieldName, type, length, decimalCount });
      }
    } else {
      // No records and no fields - create a dummy field
      fields.push({ name: 'DUMMY', type: 'C', length: 10, decimalCount: 0 });
    }
  }

  const numRecords = records.length;
  const numFields = fields.length;

  // Header length = 32 (base) + 32 * numFields + 1 (0x0D terminator)
  const headerLength = 32 + 32 * numFields + 1;

  // Record length = 1 (delete flag) + sum of field lengths
  let recordLength = 1;
  for (const f of fields) {
    recordLength += f.length;
  }

  // Total file length = header + records + 1 (0x1A EOF)
  const totalLength = headerLength + recordLength * numRecords + 1;

  const buffer = new ArrayBuffer(totalLength);
  const view = new DataView(buffer);

  // 2. Write Header (32 bytes)
  view.setUint8(0, 0x03); // Signature: dBASE III
  
  const today = new Date();
  view.setUint8(1, today.getFullYear() % 100); // YY
  view.setUint8(2, today.getMonth() + 1);       // MM
  view.setUint8(3, today.getDate());            // DD
  
  view.setUint32(4, numRecords, true);          // Number of records
  view.setUint16(8, headerLength, true);        // Header length
  view.setUint16(10, recordLength, true);       // Record length

  // 3. Write Field Descriptors (32 bytes each)
  let offset = 32;
  const encoder = new TextEncoder(); // UTF-8 encoder, we'll write standard single-byte chars

  for (const f of fields) {
    // Name (bytes 0-10): null-padded
    const encodedName = encoder.encode(f.name.toUpperCase());
    for (let i = 0; i < 11; i++) {
      if (i < encodedName.length) {
        view.setUint8(offset + i, encodedName[i]);
      } else {
        view.setUint8(offset + i, 0); // null padding
      }
    }

    // Type (byte 11)
    view.setUint8(offset + 11, f.type.charCodeAt(0));

    // Length (byte 16)
    view.setUint8(offset + 16, f.length);

    // Decimals (byte 17)
    view.setUint8(offset + 17, f.decimalCount);

    // Bytes 12-15 and 18-31 are filled with 0 (reserved)
    for (let i = 12; i <= 15; i++) view.setUint8(offset + i, 0);
    for (let i = 18; i <= 31; i++) view.setUint8(offset + i, 0);

    offset += 32;
  }

  // Header terminator (0x0D)
  view.setUint8(offset, 0x0D);
  offset++;

  // 4. Write Records
  for (const record of records) {
    // Delete flag (0x20 = space, active record)
    view.setUint8(offset, 0x20);
    let fOffset = offset + 1;

    for (const f of fields) {
      // Find the value in the record. Be lenient with field name capitalization
      let val = record[f.name];
      if (val === undefined) {
        val = record[f.name.toLowerCase()];
      }
      if (val === undefined) {
        // Fuzzy search for column names
        const upperK = Object.keys(record).find(
          k => k.toUpperCase().replace(/[^A-Z0-9_]/g, '_') === f.name
        );
        if (upperK) val = record[upperK];
      }
      if (val === undefined || val === null) {
        val = '';
      }

      let strVal = '';
      if (f.type === 'N') {
        const num = Number(val);
        if (isNaN(num)) {
          strVal = '';
        } else {
          strVal = num.toFixed(f.decimalCount);
        }
        // Left pad with spaces for Numeric fields
        strVal = strVal.padStart(f.length, ' ');
      } else if (f.type === 'L') {
        const truthy = val === true || String(val).toUpperCase() === 'T' || String(val).toUpperCase() === 'Y' || val === 1;
        strVal = truthy ? 'T' : 'F';
      } else if (f.type === 'D') {
        // Handle dates, expect YYYY-MM-DD or similar and convert to YYYYMMDD
        const dateStr = String(val).replace(/[^0-9]/g, '');
        if (dateStr.length >= 8) {
          strVal = dateStr.substring(0, 8);
        } else {
          strVal = dateStr.padEnd(8, ' ');
        }
      } else {
        // Character fields
        strVal = String(val);
        // Right pad with spaces for Character fields
        strVal = strVal.padEnd(f.length, ' ');
      }

      // Safeguard against multibyte UTF-8 characters causing overflow.
      // Write byte-by-byte. If character is outside standard ASCII, substitute '?' or similar
      // to guarantee we stay within f.length bytes exactly.
      for (let i = 0; i < f.length; i++) {
        const code = i < strVal.length ? strVal.charCodeAt(i) : 32; // 32 is space
        // Cap at 255 for binary safety. If it's outside extended ASCII, write 63 ('?')
        view.setUint8(fOffset + i, code > 255 ? 63 : code);
      }

      fOffset += f.length;
    }

    offset += recordLength;
  }

  // 5. Write File Terminator (0x1A)
  view.setUint8(offset, 0x1A);

  return buffer;
}
