import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Flower2, 
  Download, 
  RefreshCw, 
  HelpCircle, 
  X, 
  AlertCircle, 
  Heart, 
  Sparkles,
  CheckCircle2
} from 'lucide-react';

import { WizardProgress } from './components/WizardProgress';
import { DropZone } from './components/DropZone';
import { FormatSelector } from './components/FormatSelector';
import { DataPreview } from './components/DataPreview';
import { CuteButton } from './components/CuteButton';
import { parseFile, convertAndDownload, triggerDownload, SupportedFormat, ParsedFile } from './utils/converter';

export default function App() {
  // Wizard State
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<ParsedFile | null>(null);
  const [selectedFormat, setSelectedFormat] = useState<SupportedFormat | null>(null);
  const [convertedFile, setConvertedFile] = useState<{ blob: Blob; fileName: string } | null>(null);
  
  // UI Status State
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingMessage, setProcessingMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [showHelp, setShowHelp] = useState(false);

  // 1. Handle File Upload (Step 1 -> 2)
  const handleFileAccepted = async (uploadedFile: File) => {
    setError(null);
    setIsProcessing(true);
    setProcessingMessage('Reading your file... Just a moment! 🐹');
    setFile(uploadedFile);

    try {
      // Adding a slight delay so the elderly user can feel that work is happening,
      // which aligns with mental models of "processing" and reduces UI jitter.
      await new Promise(resolve => setTimeout(resolve, 1200));
      const parsed = await parseFile(uploadedFile);
      setParsedData(parsed);
      setCurrentStep(2);
    } catch (err: any) {
      setError(err.message || 'I couldn\'t read that file. Is it open in another program? 🐻');
      setFile(null);
      setParsedData(null);
    } finally {
      setIsProcessing(false);
      setProcessingMessage('');
    }
  };

  // 2. Handle Conversion Action (Step 2 -> 3)
  const handleConvert = async () => {
    if (!parsedData || !selectedFormat) return;

    setError(null);
    setIsProcessing(true);
    setProcessingMessage('Doing my magic! Typing as fast as I can... 🦄✨');

    try {
      // Satisfying visual delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      const result = convertAndDownload(
        parsedData.rows,
        selectedFormat,
        parsedData.name,
        parsedData.headers
      );

      setConvertedFile(result);
      setCurrentStep(3);
    } catch (err: any) {
      setError(err.message || 'Oh dear, the conversion failed! Please try again. 🐱');
    } finally {
      setIsProcessing(false);
      setProcessingMessage('');
    }
  };

  // 3. Handle Download Action (Step 3)
  const handleDownload = () => {
    if (!convertedFile) return;
    triggerDownload(convertedFile.blob, convertedFile.fileName);
  };

  // 4. Reset Wizard (Back to Step 1)
  const handleReset = () => {
    setCurrentStep(1);
    setFile(null);
    setParsedData(null);
    setSelectedFormat(null);
    setConvertedFile(null);
    setError(null);
  };

  // UI Animation Variants
  const cardVariants: any = {
    initial: { opacity: 0, y: 40, scale: 0.98 },
    animate: { 
      opacity: 1, 
      y: 0, 
      scale: 1, 
      transition: { type: 'spring', stiffness: 100, damping: 15 } 
    },
    exit: { 
      opacity: 0, 
      y: -40, 
      scale: 0.98,
      transition: { duration: 0.2 } 
    }
  };

  const activeFormats = parsedData ? [parsedData.extension] : [];

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-100 via-purple-50 to-sky-100 font-sans text-slate-800 pb-20 relative overflow-x-hidden select-none">
      
      {/* Decorative Sakura/Motif floating elements (pure visual joy) */}
      <div className="absolute top-10 left-[5%] text-5xl opacity-40 animate-spin-slow select-none pointer-events-none">🌸</div>
      <div className="absolute top-24 right-[8%] text-4xl opacity-40 animate-bounce-slow select-none pointer-events-none">✨</div>
      <div className="absolute bottom-40 left-[3%] text-6xl opacity-30 animate-pulse select-none pointer-events-none">🌸</div>
      <div className="absolute bottom-1/2 right-[4%] text-5xl opacity-30 animate-bounce-slow select-none pointer-events-none">🌿</div>
      <div className="absolute top-1/3 left-[90%] text-4xl opacity-30 animate-spin-slow select-none pointer-events-none">💮</div>
      
      {/* HEADER SECTION */}
      <header className="w-full text-center py-12 px-4 border-b-4 border-slate-800 bg-white shadow-[0px_4px_0px_0px_#1e293b] mb-12">
        <div className="max-w-4xl mx-auto flex flex-col items-center justify-center gap-2">
          <div className="inline-flex items-center gap-4 bg-pink-100 border-4 border-slate-800 rounded-full px-8 py-2 shadow-[3px_3px_0px_0px_#1e293b] animate-bounce-slow mb-4">
            <Flower2 className="w-10 h-10 text-pink-500 animate-spin-slow" />
            <span className="text-2xl font-black tracking-wide text-pink-900">SUGAR-SWEET FILE SWAPPER</span>
            <Flower2 className="w-10 h-10 text-pink-500 animate-spin-slow" />
          </div>
          <h1 className="text-5xl md:text-6xl font-black tracking-tight text-slate-800 leading-tight">
            Super Easy File Converter 🌸
          </h1>
          <p className="text-2xl font-bold text-slate-500 max-w-3xl leading-relaxed mt-2">
            Hello, friend! I can change your spreadsheet files into any format you need. 
            It is completely private and takes just 3 simple steps! 
          </p>
        </div>
      </header>

      <main className="w-full relative z-10">
        {/* WIZARD PROGRESS INDICATOR */}
        <WizardProgress currentStep={currentStep} />

        <div className="max-w-5xl mx-auto px-4 mt-6">
          {/* ERROR DISPLAY */}
          <AnimatePresence>
            {error && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="mb-8 border-4 border-slate-800 bg-red-100 rounded-3xl p-6 shadow-[6px_6px_0px_0px_#1e293b] flex flex-col md:flex-row items-center gap-6 text-red-950"
                role="alert"
              >
                <div className="w-20 h-20 rounded-2xl bg-red-200 border-4 border-slate-800 flex items-center justify-center flex-shrink-0 shadow-[2px_2px_0px_0px_#1e293b]">
                  <AlertCircle className="w-12 h-12 text-red-800" />
                </div>
                <div className="flex-1 text-center md:text-left">
                  <h3 className="text-3xl font-black mb-1">Oh Bother! An Error Occurred...</h3>
                  <p className="text-xl font-bold leading-snug">{error}</p>
                </div>
                <CuteButton 
                  variant="yellow" 
                  size="large" 
                  onClick={() => setError(null)}
                  aria-label="Dismiss error message"
                >
                  Try Again! 🐾
                </CuteButton>
              </motion.div>
            )}
          </AnimatePresence>

          {/* MAIN WIZARD CONTAINER */}
          <div className="w-full bg-white border-4 border-slate-800 rounded-[40px] p-6 md:p-12 shadow-[12px_12px_0px_0px_#1e293b] relative overflow-hidden">
            
            {/* Background Cute Accents */}
            <div className="absolute -bottom-6 -left-6 text-9xl opacity-10 select-none pointer-events-none">🐱</div>
            <div className="absolute -top-6 -right-6 text-9xl opacity-10 select-none pointer-events-none">🐻</div>

            <AnimatePresence mode="wait">
              {/* STEP 1: UPLOAD FILE */}
              {currentStep === 1 && (
                <motion.div
                  key="step1"
                  variants={cardVariants}
                  initial="initial"
                  animate="animate"
                  exit="exit"
                >
                  <DropZone 
                    onFileAccepted={handleFileAccepted}
                    isProcessing={isProcessing}
                  />
                </motion.div>
              )}

              {/* STEP 2: SELECT FORMAT & PREVIEW */}
              {currentStep === 2 && parsedData && (
                <motion.div
                  key="step2"
                  variants={cardVariants}
                  initial="initial"
                  animate="animate"
                  exit="exit"
                  className="flex flex-col items-center"
                >
                  {/* Selected file card summary */}
                  <div className="w-full max-w-4xl mx-auto px-4 mb-10 flex items-center gap-4 bg-purple-50 p-6 border-4 border-slate-800 rounded-3xl shadow-[4px_4px_0px_0px_#1e293b]">
                    <div className="w-14 h-14 rounded-full bg-pink-200 border-2 border-slate-800 flex items-center justify-center font-bold text-2xl shadow-[2px_2px_0px_0px_#000]">
                      📁
                    </div>
                    <div>
                      <p className="text-sm font-black text-purple-800 tracking-wider">YOUR LOADED FILE:</p>
                      <p className="text-3xl font-black text-slate-800 break-all">{file?.name}</p>
                    </div>
                  </div>

                  <FormatSelector 
                    selected={selectedFormat}
                    onSelect={setSelectedFormat}
                    disabledFormats={activeFormats}
                  />

                  {/* NAV BUTTONS FOR STEP 2 */}
                  <div className="flex flex-col sm:flex-row gap-6 mt-12 w-full max-w-4xl px-4 justify-center">
                    <CuteButton
                      variant="yellow"
                      size="large"
                      emoji="⬅️"
                      onClick={handleReset}
                      disabled={isProcessing}
                      className="w-full sm:w-auto"
                      aria-label="Go back to file upload step"
                    >
                      Go Back
                    </CuteButton>
                    
                    <CuteButton
                      variant="green"
                      size="huge"
                      emoji="🐻"
                      onClick={handleConvert}
                      disabled={!selectedFormat || isProcessing}
                      className="w-full sm:flex-1"
                      aria-label="Convert the file now"
                    >
                      Convert File Now!
                    </CuteButton>
                  </div>

                  <DataPreview 
                    rows={parsedData.rows}
                    headers={parsedData.headers}
                    fileName={file?.name || 'Your File'}
                  />
                </motion.div>
              )}

              {/* STEP 3: CONVERT & DOWNLOAD */}
              {currentStep === 3 && convertedFile && (
                <motion.div
                  key="step3"
                  variants={cardVariants}
                  initial="initial"
                  animate="animate"
                  exit="exit"
                  className="text-center py-8"
                >
                  <div className="w-28 h-28 rounded-full border-4 border-slate-800 bg-emerald-200 flex items-center justify-center mx-auto mb-6 shadow-[4px_4px_0px_0px_#1e293b] animate-bounce-slow">
                    <CheckCircle2 className="w-16 h-16 text-emerald-800 stroke-[3px]" />
                  </div>

                  <h2 className="text-5xl font-black text-slate-800 mb-4 tracking-wide">
                    🎉 Hooray! It Is Ready! 🎉
                  </h2>
                  
                  <p className="text-2xl font-bold text-slate-600 max-w-2xl mx-auto mb-10 leading-relaxed">
                    I have successfully made your brand new <span className="text-emerald-700 font-black px-2 py-1 bg-emerald-50 border-2 border-emerald-300 rounded-lg">.{selectedFormat}</span> file! 
                    It is sitting inside my magic box. Click the giant button below to save it onto your computer!
                  </p>

                  {/* GIANT DOWNLOAD TARGET */}
                  <div className="mb-12 max-w-2xl mx-auto border-4 border-slate-800 rounded-[32px] p-8 bg-yellow-50 shadow-[6px_6px_0px_0px_#1e293b] relative">
                    <div className="absolute -top-5 right-10 text-4xl select-none animate-pulse">🌟</div>
                    <div className="absolute bottom-2 left-6 text-3xl select-none animate-bounce-slow">✨</div>

                    <p className="text-xl font-black text-slate-500 mb-2 text-left">READY FOR DOWNLOAD:</p>
                    <p className="text-3xl font-black text-slate-800 break-all text-left mb-6 flex items-center gap-2">
                      <span>📄</span> {convertedFile.fileName}
                    </p>

                    <CuteButton
                      variant="pink"
                      size="huge"
                      icon={<Download />}
                      emoji="🎁"
                      onClick={handleDownload}
                      className="w-full"
                      aria-label={`Download your converted file: ${convertedFile.fileName}`}
                    >
                      Download My File!
                    </CuteButton>
                  </div>

                  <div className="border-t-4 border-dashed border-slate-200 pt-8 max-w-md mx-auto">
                    <p className="text-xl font-bold text-slate-500 mb-6">
                      Have another file to convert? No problem! 🐻
                    </p>
                    <CuteButton
                      variant="blue"
                      size="large"
                      icon={<RefreshCw />}
                      onClick={handleReset}
                      className="w-full"
                      aria-label="Start over and convert another file"
                    >
                      Convert Another File!
                    </CuteButton>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* LOADING OVERLAY */}
      <AnimatePresence>
        {isProcessing && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-white/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
            aria-label="Processing file, please wait"
          >
            <div className="relative w-44 h-44 border-8 border-slate-800 rounded-full bg-pink-100 flex items-center justify-center shadow-[10px_10px_0px_0px_#1e293b] animate-bounce">
              <Flower2 className="w-24 h-24 text-pink-500 animate-spin-slow" />
              <div className="absolute text-4xl select-none">🐹</div>
            </div>
            <h3 className="text-4xl font-black text-slate-800 mt-12 tracking-wide mb-2 animate-pulse">
              Working on it! 💖
            </h3>
            <p className="text-2xl font-black text-pink-700 bg-pink-100 border-4 border-slate-800 px-8 py-3 rounded-2xl shadow-[4px_4px_0px_0px_#1e293b]">
              {processingMessage}
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* HELP BUTTON AND WIDGET */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setShowHelp(!showHelp)}
          className="w-20 h-20 bg-yellow-300 hover:bg-yellow-200 text-slate-900 rounded-full border-4 border-slate-800 flex items-center justify-center shadow-[4px_4px_0px_0px_#1e293b] focus:outline-none focus:ring-8 focus:ring-yellow-100 active:translate-y-0.5 active:shadow-none transition-all"
          aria-label="Open or close help panel"
          aria-expanded={showHelp}
        >
          {showHelp ? <X className="w-10 h-10 stroke-[3px]" /> : <HelpCircle className="w-10 h-10 stroke-[3px]" />}
        </button>
      </div>

      <AnimatePresence>
        {showHelp && (
          <motion.div 
            initial={{ opacity: 0, y: 100, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.8 }}
            className="fixed bottom-28 right-6 w-full max-w-lg bg-white border-4 border-slate-800 rounded-3xl p-8 shadow-[12px_12px_0px_0px_#1e293b] z-40 text-slate-800"
            role="complementary"
            aria-label="Help and instructions"
          >
            <div className="flex items-center gap-4 mb-4 border-b-4 border-dashed border-slate-300 pb-4">
              <div className="text-4xl">🐻</div>
              <div>
                <h4 className="text-3xl font-black">Need a Hand, Friend?</h4>
                <p className="text-lg font-bold text-slate-500">I am here to help you step-by-step!</p>
              </div>
            </div>

            <ol className="space-y-4 text-xl font-bold list-none p-0">
              <li className="flex items-start gap-3">
                <span className="flex-shrink-0 w-8 h-8 rounded-full bg-pink-200 border-2 border-slate-800 flex items-center justify-center text-sm font-black shadow-[1px_1px_0px_0px_#000]">1</span>
                <span>
                  <strong className="text-pink-700">Step 1:</strong> Drag your file from your desktop and drop it into the giant box, OR click the big pink button to select it from your computer!
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-200 border-2 border-slate-800 flex items-center justify-center text-sm font-black shadow-[1px_1px_0px_0px_#000]">2</span>
                <span>
                  <strong className="text-emerald-700">Step 2:</strong> Look at the cards and click on the format you want. <em className="font-normal">(Hint: Excel is usually best!)</em> Click the big green button to convert it.
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex-shrink-0 w-8 h-8 rounded-full bg-pink-200 border-2 border-slate-800 flex items-center justify-center text-sm font-black shadow-[1px_1px_0px_0px_#000]">3</span>
                <span>
                  <strong className="text-pink-700">Step 3:</strong> Click the giant <strong className="font-black">Download My File!</strong> button. That's it! Your file will be in your "Downloads" folder.
                </span>
              </li>
            </ol>

            <div className="mt-6 pt-4 border-t-2 border-slate-200 flex items-center gap-2 text-lg text-slate-500 font-bold justify-center">
              <span>Made with</span> 
              <Heart className="w-5 h-5 text-red-500 fill-red-500 animate-pulse" /> 
              <span>for our wonderful staff.</span>
            </div>

            <button 
              onClick={() => setShowHelp(false)}
              className="mt-6 w-full py-3 bg-slate-100 hover:bg-slate-200 border-4 border-slate-800 text-xl font-black rounded-2xl shadow-[4px_4px_0px_0px_#1e293b] active:translate-y-0.5 active:shadow-none transition-all"
            >
              Okay, I Got It! 👍
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FOOTER SECTION */}
      <footer className="w-full text-center mt-20 text-xl font-bold text-slate-500 flex flex-col items-center gap-2">
        <p className="flex items-center gap-2">
          <span>🌸</span> 
          <span>Sugar-Sweet File Swapper</span>
          <span>🌸</span>
        </p>
        <p className="text-sm font-medium bg-white/50 backdrop-blur-sm border border-slate-300 px-4 py-1 rounded-full shadow-sm flex items-center gap-1">
          <Sparkles className="w-4 h-4 text-yellow-500" /> 
          Private & Secure: Files never leave your browser! 
          <Sparkles className="w-4 h-4 text-yellow-500" />
        </p>
      </footer>
    </div>
  );
}
