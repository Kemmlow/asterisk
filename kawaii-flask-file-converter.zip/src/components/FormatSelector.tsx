import React from 'react';
import { Check, FileSpreadsheet, Database, FileText } from 'lucide-react';
import { cn } from '../utils/cn';
import { SupportedFormat, FORMAT_INFO } from '../utils/converter';

interface FormatSelectorProps {
  selected: SupportedFormat | null;
  onSelect: (format: SupportedFormat) => void;
  disabledFormats: string[];
}

export const FormatSelector: React.FC<FormatSelectorProps> = ({
  selected,
  onSelect,
  disabledFormats
}) => {
  const formats: { id: SupportedFormat; emoji: string; icon: React.ReactNode; color: string; hoverColor: string }[] = [
    { 
      id: 'csv', 
      emoji: '📃', 
      icon: <FileText className="w-12 h-12" />, 
      color: 'bg-yellow-100 border-yellow-800 text-yellow-900',
      hoverColor: 'hover:bg-yellow-50'
    },
    { 
      id: 'xlsx', 
      emoji: '📊', 
      icon: <FileSpreadsheet className="w-12 h-12" />, 
      color: 'bg-emerald-100 border-emerald-800 text-emerald-900',
      hoverColor: 'hover:bg-emerald-50'
    },
    { 
      id: 'xls', 
      emoji: '📂', 
      icon: <FileSpreadsheet className="w-12 h-12" />, 
      color: 'bg-sky-100 border-sky-800 text-sky-900',
      hoverColor: 'hover:bg-sky-50'
    },
    { 
      id: 'dbf', 
      emoji: '🗄️', 
      icon: <Database className="w-12 h-12" />, 
      color: 'bg-purple-100 border-purple-800 text-purple-900',
      hoverColor: 'hover:bg-purple-50'
    },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto px-4">
      <h3 className="text-3xl font-black text-slate-800 text-center mb-8 tracking-wide">
        🐻 Step 2: Choose Your New File Format! 🐻
      </h3>
      
      <p className="text-xl font-bold text-slate-600 text-center mb-10 max-w-2xl mx-auto leading-relaxed">
        Click on the big colorful card for the file format you want. 
        If you aren't sure, <span className="text-emerald-700 font-extrabold underline">Excel (.xlsx)</span> is usually the best choice for spreadsheets!
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {formats.map((fmt) => {
          const isSelected = selected === fmt.id;
          const info = FORMAT_INFO[fmt.id];
          const isDisabled = disabledFormats.includes(fmt.id);

          return (
            <button
              key={fmt.id}
              onClick={() => !isDisabled && onSelect(fmt.id)}
              disabled={isDisabled}
              className={cn(
                "relative flex items-start gap-6 p-6 border-4 border-slate-800 rounded-3xl text-left transition-all duration-200 active:translate-y-1 active:shadow-none focus:outline-none focus:ring-8 focus:ring-pink-200 disabled:opacity-40 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-none",
                isSelected 
                  ? `${fmt.color} shadow-[8px_8px_0px_0px_#1e293b] scale-[1.03]` 
                  : `bg-white text-slate-800 hover:border-pink-500 shadow-[5px_5px_0px_0px_#1e293b] hover:-translate-y-1 hover:shadow-[10px_10px_0px_0px_#1e293b]`
              )}
              aria-pressed={isSelected}
              aria-label={`Select output format ${info.name}. ${info.desc}`}
            >
              {/* Checkmark badge */}
              {isSelected && (
                <div className="absolute -top-5 -right-5 w-12 h-12 rounded-full border-4 border-slate-800 bg-emerald-400 flex items-center justify-center shadow-[2px_2px_0px_0px_#1e293b] animate-bounce-slow">
                  <Check className="w-8 h-8 text-slate-900 stroke-[4px]" />
                </div>
              )}

              {/* Format Icon */}
              <div className={cn(
                "flex-shrink-0 w-20 h-20 border-4 border-slate-800 rounded-2xl flex items-center justify-center shadow-[3px_3px_0px_0px_#1e293b]",
                isSelected ? "bg-white text-slate-900" : fmt.color
              )}>
                {fmt.icon}
              </div>

              {/* Format Text */}
              <div className="flex-1 pr-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-3xl font-black">{info.label}</span>
                  {isSelected && <span className="text-2xl animate-pulse">{fmt.emoji}</span>}
                </div>
                <p className={cn(
                  "text-lg leading-snug font-bold",
                  isSelected ? "text-slate-800" : "text-slate-500"
                )}>
                  {info.desc}
                </p>
                {isDisabled && (
                  <p className="mt-2 text-sm font-extrabold text-red-600">
                    ⚠️ This is the same format as your original file!
                  </p>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
