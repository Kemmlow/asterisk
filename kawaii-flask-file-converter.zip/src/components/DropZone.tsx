import React, { useState, useRef } from 'react';
import { Upload, FilePlus, Sparkles } from 'lucide-react';
import { cn } from '../utils/cn';
import { CuteButton } from './CuteButton';

interface DropZoneProps {
  onFileAccepted: (file: File) => void;
  isProcessing: boolean;
}

export const DropZone: React.FC<DropZoneProps> = ({ onFileAccepted, isProcessing }) => {
  const [isDragActive, setIsDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true);
    } else if (e.type === "dragleave") {
      setIsDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    if (isProcessing) return;

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0];
      validateAndAcceptFile(droppedFile);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      validateAndAcceptFile(e.target.files[0]);
    }
  };

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const validateAndAcceptFile = (file: File) => {
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext && ['csv', 'xlsx', 'xls', 'dbf'].includes(ext)) {
      onFileAccepted(file);
    } else {
      alert(`Oops! ".${ext || 'unknown'}" is not a format I can convert. Please give me a CSV, XLSX, XLS, or DBF file! 🌸`);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      triggerFileInput();
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4">
      <div 
        className={cn(
          "relative border-8 border-dashed rounded-[40px] p-12 text-center transition-all duration-300 flex flex-col items-center justify-center min-h-[450px] cursor-pointer",
          isDragActive 
            ? "border-pink-500 bg-pink-100 scale-[1.02] shadow-[12px_12px_0px_0px_#1e293b]" 
            : "border-slate-800 bg-purple-50 hover:bg-pink-50 hover:border-pink-400 shadow-[8px_8px_0px_0px_#1e293b]"
        )}
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        onClick={triggerFileInput}
        onKeyDown={handleKeyDown}
        role="button"
        tabIndex={0}
        aria-label="Drag and drop a CSV, XLSX, XLS, or DBF file here, or press Enter to browse files"
      >
        <input 
          ref={fileInputRef}
          type="file"
          accept=".csv,.xlsx,.xls,.dbf"
          onChange={handleFileSelect}
          className="hidden"
          disabled={isProcessing}
          aria-hidden="true"
        />

        {/* Decorative background motifs */}
        <div className="absolute top-4 left-4 text-4xl select-none animate-bounce-slow opacity-60">🌸</div>
        <div className="absolute bottom-6 right-8 text-4xl select-none animate-pulse opacity-60">🌿</div>
        <div className="absolute top-8 right-6 text-3xl select-none animate-spin-slow opacity-60">🌻</div>
        <div className="absolute bottom-4 left-6 text-3xl select-none animate-bounce-slow opacity-60">🐰</div>

        <div className={cn(
          "w-28 h-28 rounded-full border-4 border-slate-800 flex items-center justify-center mb-8 shadow-[4px_4px_0px_0px_#1e293b] transition-transform duration-300",
          isDragActive ? "bg-pink-300 scale-110 -rotate-12" : "bg-yellow-200"
        )}>
          {isDragActive ? (
            <FilePlus className="w-16 h-16 text-pink-900" />
          ) : (
            <Upload className="w-16 h-16 text-yellow-900" />
          )}
        </div>

        <h2 className="text-4xl font-black text-slate-800 mb-6 tracking-wide leading-tight">
          {isDragActive ? "Ooooh! Drop it right here! 👇" : "🌸 Step 1: Give Me Your File! 🌸"}
        </h2>

        <p className="text-2xl font-bold text-slate-600 max-w-2xl mb-10 leading-relaxed">
          {isDragActive 
            ? "I'm ready to catch your file! Let go of the mouse! 🎉" 
            : "Drag and drop your file anywhere inside this box, or click the big pink button below to find it on your computer!"}
        </p>

        <div onClick={(e) => e.stopPropagation()} className="w-full sm:w-auto">
          <CuteButton
            variant="pink"
            size="huge"
            emoji="📂"
            onClick={triggerFileInput}
            disabled={isProcessing}
            aria-label="Click to browse files on your computer"
          >
            {isProcessing ? "Loading File..." : "Choose a File!"}
          </CuteButton>
        </div>

        <div className="mt-8 px-6 py-2 bg-slate-800 text-white font-bold text-lg rounded-full flex items-center gap-2 shadow-[2px_2px_0px_0px_#000]">
          <Sparkles className="w-5 h-5 text-yellow-300" />
          <span>I can read: .csv, .xlsx, .xls, and .dbf files!</span>
          <Sparkles className="w-5 h-5 text-yellow-300" />
        </div>
      </div>
    </div>
  );
};
