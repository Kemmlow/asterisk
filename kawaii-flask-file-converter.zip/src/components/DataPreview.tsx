import React from 'react';
import { Table, ArrowRightLeft } from 'lucide-react';

interface DataPreviewProps {
  rows: any[];
  headers: string[];
  fileName: string;
}

export const DataPreview: React.FC<DataPreviewProps> = ({ rows, headers, fileName }) => {
  const previewRows = rows.slice(0, 5); // Peek at first 5 rows
  const recordCount = rows.length;
  const columnCount = headers.length;

  return (
    <div className="w-full max-w-4xl mx-auto px-4 mt-12 bg-white border-4 border-slate-800 rounded-3xl p-8 shadow-[8px_8px_0px_0px_#1e293b]">
      <div className="flex items-center gap-4 mb-6 border-b-4 border-dashed border-slate-300 pb-4">
        <div className="w-16 h-16 rounded-2xl bg-blue-200 border-4 border-slate-800 flex items-center justify-center shadow-[2px_2px_0px_0px_#1e293b]">
          <Table className="w-10 h-10 text-blue-900" />
        </div>
        <div>
          <h4 className="text-3xl font-black text-slate-800 tracking-wide">
            👀 File Preview: {fileName}
          </h4>
          <p className="text-xl font-bold text-slate-600">
            I found <span className="text-pink-600 font-extrabold">{recordCount}</span> rows and <span className="text-blue-600 font-extrabold">{columnCount}</span> columns in your file!
          </p>
        </div>
      </div>

      <p className="text-xl font-bold text-slate-700 mb-6 flex items-center gap-2">
        <span className="text-2xl animate-bounce-slow">🌸</span> 
        Here is a little peek at the first 5 rows of your file so you can double check it:
      </p>

      {/* Responsive horizontal scroll container */}
      <div className="overflow-x-auto border-4 border-slate-800 rounded-2xl max-w-full shadow-[4px_4px_0px_0px_#1e293b]">
        <table className="w-full text-left border-collapse min-w-max">
          <thead>
            <tr className="bg-slate-800 text-white border-b-4 border-slate-800">
              {headers.map((h, i) => (
                <th 
                  key={i} 
                  className="px-6 py-4 text-2xl font-black tracking-wide border-r-2 border-slate-600 last:border-r-0 whitespace-nowrap"
                  scope="col"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {previewRows.map((row, rowIndex) => (
              <tr 
                key={rowIndex} 
                className="border-b-2 border-slate-300 last:border-b-0 odd:bg-pink-50/50 even:bg-white text-slate-800 text-xl font-bold hover:bg-yellow-50"
              >
                {headers.map((h, colIndex) => {
                  const val = row[h];
                  const displayVal = val === null || val === undefined ? '' : String(val);
                  return (
                    <td 
                      key={colIndex} 
                      className="px-6 py-4 border-r-2 border-slate-200 last:border-r-0 truncate max-w-xs"
                    >
                      {displayVal || <span className="text-slate-300 font-normal">empty</span>}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {recordCount > 5 && (
        <div className="mt-4 text-center">
          <p className="text-lg font-extrabold text-slate-500 bg-slate-100 py-2 px-6 inline-flex items-center gap-2 rounded-full border-2 border-slate-400">
            <ArrowRightLeft className="w-5 h-5" />
            And {recordCount - 5} more rows are hidden... but they are all there!
          </p>
        </div>
      )}
    </div>
  );
};
