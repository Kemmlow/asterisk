import React from 'react';
import { cn } from '../utils/cn';

interface CuteButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'pink' | 'lavender' | 'blue' | 'green' | 'yellow';
  size?: 'large' | 'huge';
  icon?: React.ReactNode;
  emoji?: string;
}

export const CuteButton: React.FC<CuteButtonProps> = ({
  children,
  variant = 'pink',
  size = 'huge',
  icon,
  emoji,
  className,
  disabled,
  ...props
}) => {
  const baseStyles = "relative inline-flex items-center justify-center font-bold tracking-wide transition-all duration-200 active:translate-y-1 active:shadow-none border-4 border-slate-800 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:translate-y-0 disabled:active:shadow-neubrutal";

  const sizeStyles = {
    large: "text-2xl px-8 py-4 rounded-2xl shadow-[5px_5px_0px_0px_#1e293b]",
    huge: "text-3xl px-12 py-6 rounded-3xl shadow-[8px_8px_0px_0px_#1e293b] w-full md:w-auto"
  };

  const variantStyles = {
    pink: "bg-pink-200 text-pink-950 hover:bg-pink-100 hover:-translate-y-0.5 hover:shadow-[10px_10px_0px_0px_#1e293b]",
    lavender: "bg-purple-200 text-purple-950 hover:bg-purple-100 hover:-translate-y-0.5 hover:shadow-[10px_10px_0px_0px_#1e293b]",
    blue: "bg-blue-200 text-blue-950 hover:bg-blue-100 hover:-translate-y-0.5 hover:shadow-[10px_10px_0px_0px_#1e293b]",
    green: "bg-emerald-200 text-emerald-950 hover:bg-emerald-100 hover:-translate-y-0.5 hover:shadow-[10px_10px_0px_0px_#1e293b]",
    yellow: "bg-yellow-200 text-yellow-950 hover:bg-yellow-100 hover:-translate-y-0.5 hover:shadow-[10px_10px_0px_0px_#1e293b]"
  };

  return (
    <button
      className={cn(
        baseStyles,
        sizeStyles[size],
        variantStyles[variant],
        disabled && "shadow-none active:translate-y-0 bg-slate-100 border-slate-400 text-slate-400",
        className
      )}
      disabled={disabled}
      {...props}
    >
      <div className="flex items-center justify-center gap-4">
        {emoji && (
          <span 
            className={cn(
              "select-none transition-transform duration-300 group-hover:scale-125 animate-bounce-slow",
              size === 'huge' ? 'text-4xl' : 'text-3xl'
            )} 
            aria-hidden="true"
          >
            {emoji}
          </span>
        )}
        
        {icon && (
          <span 
            className={cn(
              "flex items-center justify-center font-bold transition-transform group-hover:rotate-12",
              size === 'huge' ? '[&>svg]:w-10 [&>svg]:h-10' : '[&>svg]:w-8 [&>svg]:h-8'
            )}
            aria-hidden="true"
          >
            {icon}
          </span>
        )}
        
        <span>{children}</span>
      </div>
    </button>
  );
};
