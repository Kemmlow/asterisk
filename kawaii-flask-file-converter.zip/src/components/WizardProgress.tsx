import React from 'react';
import { Check, Flower2, PawPrint, Sparkles } from 'lucide-react';
import { cn } from '../utils/cn';

interface WizardProgressProps {
  currentStep: 1 | 2 | 3;
}

export const WizardProgress: React.FC<WizardProgressProps> = ({ currentStep }) => {
  const steps = [
    { number: 1, label: 'Choose File', emoji: '📂', icon: <PawPrint className="w-8 h-8" /> },
    { number: 2, label: 'Pick Format', emoji: '🔄', icon: <Flower2 className="w-8 h-8 animate-spin-slow" /> },
    { number: 3, label: 'Download', emoji: '✨', icon: <Sparkles className="w-8 h-8 animate-pulse" /> },
  ];

  return (
    <nav 
      className="w-full max-w-4xl mx-auto mb-12 px-4"
      aria-label="File conversion steps"
    >
      <ol className="flex items-center justify-between w-full relative">
        {/* Connecting line */}
        <div 
          className="absolute top-10 left-0 right-0 h-2 bg-slate-800 rounded-full z-0 mx-12 md:mx-20"
          aria-hidden="true"
        >
          <div 
            className="h-full bg-pink-400 transition-all duration-500 rounded-full"
            style={{ width: `${((currentStep - 1) / 2) * 100}%` }}
          />
        </div>

        {steps.map((step) => {
          const isCompleted = currentStep > step.number;
          const isActive = currentStep === step.number;
          const isFuture = currentStep < step.number;

          return (
            <li 
              key={step.number}
              className="flex flex-col items-center relative z-10 flex-1"
              aria-current={isActive ? 'step' : undefined}
            >
              <div 
                className={cn(
                  "w-20 h-20 rounded-full border-4 flex items-center justify-center text-3xl font-bold transition-all duration-300 shadow-[4px_4px_0px_0px_#1e293b]",
                  isCompleted && "bg-emerald-200 border-slate-800 text-slate-800 scale-105",
                  isActive && "bg-pink-300 border-slate-800 text-slate-900 scale-110 ring-8 ring-pink-100 ring-opacity-80",
                  isFuture && "bg-white border-slate-300 text-slate-400 shadow-none"
                )}
              >
                {isCompleted ? (
                  <Check className="w-10 h-10 stroke-[3px] text-emerald-800" />
                ) : (
                  <span className="flex items-center justify-center">
                    {isActive ? (
                      <span className="flex flex-col items-center justify-center">
                        <span className="text-sm absolute -top-1 px-3 py-1 bg-slate-800 text-white rounded-full font-bold">
                          HERE
                        </span>
                        {step.emoji}
                      </span>
                    ) : (
                      step.number
                    )}
                  </span>
                )}
              </div>
              
              <span 
                className={cn(
                  "mt-4 text-2xl font-black text-center tracking-wide md:px-2 py-1 rounded-xl transition-all",
                  isActive && "text-slate-800 bg-pink-100 px-4 border-2 border-slate-800 shadow-[3px_3px_0px_0px_#1e293b]",
                  isCompleted && "text-slate-600 font-bold",
                  isFuture && "text-slate-400"
                )}
              >
                {step.label}
              </span>
            </li>
          );
        })}
      </ol>
    </nav>
  );
};
